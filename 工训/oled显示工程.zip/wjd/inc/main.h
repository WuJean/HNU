#include <STC15F2K60S2.h>
#include "oled.h"
#include "bmp.h"
#include "stdlib.h"

sbit key1 = P3 ^ 2; //按键1
sbit key2 = P3 ^ 3; //按键2
sbit key3 = P1 ^ 7; //按键3

unsigned char main_page = 0; //主界面
unsigned char menu_page = 0; //菜单界面 
unsigned char menu_num = 0; // 0 to 2
unsigned char vedio_page = 0; //视频界面
unsigned char content_page = 0; //内容界面
unsigned char content_num = 0; //内容菜单 from 0 to 2
unsigned char about_page = 0; //关于界面

/**********************
函数名称：void delay(unsigned int xms)
功能描述：延时
入口参数：xms：输入需要延时å的毫秒值
出口参数：无
备注：

***********************/
void delay(unsigned int xms)
{
    unsigned int i, j;
    for (i = xms; i > 0; i--)
        for (j = 124; j > 0; j--)
            ;
}

void vedio(){
    while (1){
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc1);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc2);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc3);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc4);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc5);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc6);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc7);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc8);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc9);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc10);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc11);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc12);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc13);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc14);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc15);
        if (key3 == 0)
            break;
        delay_ms(30);
        //next
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc17);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc18);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc19);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc20);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc21);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc22);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc23);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc24);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc25);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc26);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc27);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc28);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc29);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc30);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc31);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc32);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc33);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc34);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc35);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc36);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc37);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc38);
        if (key3 == 0)
            break;
        delay_ms(30);
        OLED_DrawBMP1(32, 0, 64, 64, gImage_xc39);
        if (key3 == 0)
            break;
        delay_ms(30);
    }
}

void content()
{
        while (1)
        {
            if(content_num==0&&content_page==1){
                delay_ms(50);
                OLED_ShowCHinese(16, 3, 0);
                OLED_ShowCHinese(32, 3, 1);
                OLED_ShowCHinese(48, 3, 2);
                OLED_ShowCHinese(64, 3, 3);
                OLED_ShowCHinese(80, 3, 14);
                OLED_ShowCHinese(96, 3, 15);
            }
            else if(content_num==1&&content_page==1){
                delay_ms(50);
                OLED_ShowCHinese(16, 3, 0);
                OLED_ShowCHinese(32, 3, 1);
                OLED_ShowCHinese(48, 3, 2);
                OLED_ShowCHinese(64, 3, 3);
                OLED_ShowCHinese(80, 3, 12);
                OLED_ShowCHinese(96, 3, 13);
            }
            else if(content_num==2&&content_page==1){
                delay_ms(50);
                OLED_ShowCHinese(16, 3, 65);
                OLED_ShowCHinese(32, 3, 66);
                OLED_ShowCHinese(48, 3, 58);
                OLED_ShowCHinese(64, 3, 59);
                OLED_ShowCHinese(80, 3, 60);
                OLED_ShowCHinese(96, 3, 61);
            }
            if(key1==0&&content_page==1){
                delay_ms(100);
                if (content_num==2){
                    content_num = 0;
                }
                else{
                    content_num++;
                }    
            }
            if (key3==0&&content_page==1){
                OLED_Clear();
                break;
            }
            else if(key3==0&&content_page==0){
                OLED_Clear();
                content_page = 1;
            }
            if(key2==0&&content_page==1){
                if(content_num==0){
                    OLED_Clear();
                    content_page = 0;
                    OLED_ShowCHinese(32, 3, 4);
                    OLED_ShowCHinese(48, 3, 5);
                    OLED_ShowCHinese(64, 3, 6);
                    OLED_ShowCHinese(80, 3, 7);

                    OLED_ShowCHinese(32, 5, 8);
                    OLED_ShowCHinese(48, 5, 9);
                    OLED_ShowCHinese(64, 5, 10);
                    OLED_ShowCHinese(80, 5, 11);
                }
                else if(content_num==1&&content_page==1){
                    OLED_Clear();
                    content_page = 0;
                    OLED_ShowCHinese(16, 0, 16);
                    OLED_ShowCHinese(32, 0, 17);
                    OLED_ShowCHinese(48, 0, 18);
                    OLED_ShowCHinese(64, 0, 19);
                    OLED_ShowCHinese(80, 0, 20);
                    OLED_ShowCHinese(96, 0, 21);
                    OLED_ShowCHinese(112, 0, 22);

                    OLED_ShowCHinese(16, 2, 23);
                    OLED_ShowCHinese(32, 2, 24);
                    OLED_ShowCHinese(48, 2, 25);
                    OLED_ShowCHinese(64, 2, 26);
                    OLED_ShowCHinese(80, 2, 27);
                    OLED_ShowCHinese(96, 2, 28);
                    OLED_ShowCHinese(112, 2, 29);

                    OLED_ShowCHinese(16, 4, 30);
                    OLED_ShowCHinese(32, 4, 31);
                    OLED_ShowCHinese(48, 4, 32);
                    OLED_ShowCHinese(64, 4, 33);
                    OLED_ShowCHinese(80, 4, 34);
                    OLED_ShowCHinese(96, 4, 35);
                    OLED_ShowCHinese(112, 4, 36);

                    OLED_ShowCHinese(16, 6, 37);
                    OLED_ShowCHinese(32, 6, 38);
                    OLED_ShowCHinese(48, 6, 39);
                    OLED_ShowCHinese(64, 6, 40);
                    OLED_ShowCHinese(80, 6, 41);
                    OLED_ShowCHinese(96, 6, 42);
                    OLED_ShowCHinese(112, 6, 43);
                }
                else if(content_num==2&&content_page==1){
                    OLED_Clear();
                    content_page = 0;
                    OLED_ShowCHinese(16, 2, 44);
                    OLED_ShowCHinese(32, 2, 45);
                    OLED_ShowCHinese(48, 2, 46);
                    OLED_ShowCHinese(64, 2, 47);
                    OLED_ShowCHinese(80, 2, 48);
                    OLED_ShowCHinese(96, 2, 49);
                    OLED_ShowCHinese(112, 2, 50);

                    OLED_ShowCHinese(16, 5, 51);
                    OLED_ShowCHinese(32, 5, 52);
                    OLED_ShowCHinese(48, 5, 53);
                    OLED_ShowCHinese(64, 5, 54);
                    OLED_ShowCHinese(80, 5, 55);
                    OLED_ShowCHinese(96, 5, 56);
                    OLED_ShowCHinese(112, 5, 57);
                }
            } 
        }
        
    }

void about(){
    while (1)
    {   
        if (key3==0)
        {
            break;
        }
        OLED_ShowCHinese(48, 2, 62);
        OLED_ShowCHinese(64, 2, 63);
        OLED_ShowCHinese(80, 2, 64);
        OLED_ShowString(0,4, "  202108010309  ", 16);
        OLED_ShowString(0,6, "wujean.github.io", 16);
    }
    
}