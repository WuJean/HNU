#include "main.h"

void main(){
    OLED_Init();
    OLED_Clear();

    key1 = 1; //三个按键设为输入状态，检测中断
    key2 = 1;
    key3 = 1;

    while (1){
        main_page = 1;
        OLED_DrawBMP(0, 0, 128, 6, BMP0);
        OLED_ShowString(0, 6, "HUNAN UNIVERSITY", 16);
        if(key1==0){
            main_page = 0;
            menu_page = 1;
			OLED_Clear();
            while (1){
                while(1){
                    if(menu_num==0&&menu_page==1){
                        OLED_DrawBMP(0, 0, 128, 8, vedio_bmp);
                    }
                    else if(menu_num==1&&menu_page==1){
						OLED_DrawBMP(0, 0, 128, 6, content_bmp1);
						//OLED_ShowString(0,4, "ABOUT", 5);
                        OLED_ShowString(0, 6, "YUE LU SHU YUAN ", 16);
                    }
                    else if(menu_num==2&&menu_page==1){
												OLED_Clear();
                        //OLED_DrawBMP(0, 0, 128, 8, about);
                        OLED_ShowString(32,4, "ABOUT ME", 8);
                    }
                    if(key1==0&&menu_page==1){
                        delay_ms(100);
                        if (menu_num==2){
                            menu_num = 0;
                        }
                        else{
                            menu_num++;
                        }    
                    }
                    if (key3==0&&menu_page==1){
                        OLED_Clear();
                        break;
                    }
                    if(key2==0&&menu_page==1){
                        if(menu_num==0){
                            OLED_Clear();
                            menu_page = 0;
                            vedio_page = 1;
                            //OLED_ShowString(32,4, "ABOUT ME", 8);
                            vedio();
                            vedio_page = 0;
                            menu_page = 1;
                        }
                        else if(menu_num==1&&menu_page==1){
                            OLED_Clear();
                            menu_page = 0;
                            content_page = 1;
                            content();
                            content_page = 0;
                            menu_page = 1;
                        }
                        else if(menu_num==2&&menu_page==1){
                            OLED_Clear();
                            menu_page = 0;
                            about_page = 1;
                            about();
                            about_page = 0;
                            menu_page = 1;
                        }
                    } 
                }
                menu_page = 0;
                break;
            }
                
        }
            
    }
}
